package org.rugom.employee;

import org.rugom.utilities.ConsoleInput;
import org.rugom.utilities.LinkedList;
public class Main {
	
	static Employee getEmployeeInput(String empType) {
		
		System.out.println("Enter the name of " + empType +": ");
		String name = ConsoleInput.getInput();
		System.out.println("Enter the address of " + empType +": ");
		String address = ConsoleInput.getInput();
		System.out.println("Enter the age of " + empType +": ");
		int age = ConsoleInput.getInt();
		System.out.println("Enter the gender of " + empType + ": ");
		boolean gender = ConsoleInput.getBoolean();
		System.out.println("Enter the Basic Salary of " + empType + ": ");
		float basicSalary = ConsoleInput.getFloat();
		
		
		if(empType == "Manager") {
			System.out.println("Enter the HRA of " + empType + ": ");
			float hra = ConsoleInput.getFloat();
			Manager emp = new Manager(name, address, age, gender, basicSalary);
			emp.setHra(hra);
			return emp;
		}else if(empType == "Engineer") {
			System.out.println("Enter the Overtime of " + empType + ": ");
			float overtime = ConsoleInput.getFloat();
			Engineer emp = new Engineer(name, address, age, gender, basicSalary);
			emp.setOvertime(overtime);	
			return emp;
		}else {
			System.out.println("Enter the Commission of " + empType + ": ");
			float commission = ConsoleInput.getFloat();
			SalesPerson emp = new SalesPerson(name, address, age, gender, basicSalary);
			emp.setCommission(commission);	
			return emp;
		}	
	}
	
	public static void main(String[] args) {
		
		//making the menu driven program
		int choice;
		
		Employee[] empArr = new Employee[60];
		LinkedList<Employee> empList = new LinkedList<>();
		int currIndex = 0;
		
		do {
			System.out.println("1.Add\n2.Delete\n3.Display\n4.Save\n5.Load\n6.Sort\n0.Exit");
			System.out.println("Enter your choice:");
			choice = ConsoleInput.getInt();
			if(currIndex > 60) {
				System.out.println("Organization is full no more employees can be added!!!");
				return;
			}
				
			
			switch(choice) {
			
				case 1:
					System.out.println("1.Manager\n2.Engineer\n3.SalesPerson\n0.Exit");
					System.out.println("Select Employee Type:");
					int empTypeSelectionChoice;
					do {
						empTypeSelectionChoice = ConsoleInput.getInt();
						
						switch(empTypeSelectionChoice) {
						case 1:{
							Employee emp = getEmployeeInput("Manager");
							empList.add(emp);
//							empArr[currIndex++] = emp;
							break;
						}
						case 2:
						{
							Employee emp = getEmployeeInput("Engineer");
							empList.add(emp);
							break;
						}
						case 3: {
							Employee emp = getEmployeeInput("SalesPerson");
							empList.add(emp);
							break;
						}
						case 0:
							System.out.println("Exiting...");
							break;
						}
						break;
						
					}while(empTypeSelectionChoice != 0);
				case 2:
					
					break;
				case 3:
					
					int displayTypeChoice;
					do {
						System.out.println("1.All\n2.Manager\n3.Engineer\n4.SalesPerson\n0.Exit");
						displayTypeChoice=ConsoleInput.getInt();
						switch(displayTypeChoice) {
							case 1:{
								
								Employee currEmp = empList.getFirst();
								
								while(currEmp != null) {
									
									System.out.println(currEmp.displayEmployee());
									currEmp = empList.getNext();
								}
								
								for(int i = 0; i < currIndex; i++) {
//									System.out.println(empArr[i].displayEmployee());
									
								}
								break;
							}
							case 2:{
								
								Employee currEmp = empList.getFirst();
								
								while(currEmp != null) {
									if(currEmp instanceof Manager) {
										
										System.out.println(currEmp.displayEmployee());
									}
									currEmp = empList.getNext();
								}
								
								for(int i = 0; i<currIndex; i++) {									
//									if(empArr[i] instance of Manager) {
//										System.out.println(empArr[i].displayEmployee());
//									}
								}
								break;
							}
							case 3:{
								for(int i = 0; i<currIndex; i++) {									
									if(empArr[i] instanceof Engineer) {
										//System.out.println(empArr[i].displayEmployee());
										
									}	
								}
								
								Employee currEmp=empList.getFirst();
								while(currEmp!=null) {
									currEmp.displayEmployee();
									if(currEmp instanceof Engineer)
										System.out.println(currEmp.displayEmployee());
									
									currEmp = empList.getNext();
									
									
								}	
								break;
							}
							case 4:{
								for(int i = 0; i<currIndex; i++) {									
									if(empArr[i] instanceof SalesPerson) {
										System.out.println(empArr[i].displayEmployee());
									}
								}
								break;
							}
							case 0:
								break;
						}	
					}while(displayTypeChoice!=0);
					
					break;
				case 4:
					System.out.println("Save Coming Soon");
					break;
				case 5:
					System.out.println("Load Coming Soon");
					break;
				case 6:
					//sort according to name ascending
					sortByNameBruteForce(empArr, currIndex);
					//sort using string compareto method
					sortByNameStringCompareTo(empArr, currIndex);
					break;
				case 0:
					System.out.println("Exiting....");
					break;
				default:
					System.out.println("Invalid Selection!!!");
					break;
			}
		}while(choice != 0);
		
	}

	private static void sortByNameStringCompareTo(Employee[] empArr, int currIndex) {
		for(int i=0;i<currIndex-1;i++) {
			int indexOfFirstString = i;
			
			
			for(int j=i+1;j<currIndex;j++) {
				String firstString=empArr[indexOfFirstString].getName();
				String secondString=empArr[j].getName();
				
				
				if(secondString.compareToIgnoreCase(firstString)<0) {
				indexOfFirstString=j;
				
				
			}
		}
			if(indexOfFirstString !=i) {
				Employee temp=empArr[i];
				empArr[i]=empArr[indexOfFirstString];
				empArr[indexOfFirstString]=temp;
			}
		
		}
	}

	private static void sortByNameBruteForce(Employee[] empArr, int employeeCount) {
		
		for(int firstIndex = 0; firstIndex < employeeCount - 1; firstIndex++) {
			for(int secondIndex = firstIndex + 1; secondIndex < employeeCount; secondIndex++) {
				String firstString = empArr[firstIndex].getName();
				String secondString = empArr[secondIndex].getName();
				
				String firstLower = firstString.toLowerCase();
				String secondLower = secondString.toLowerCase();
				
				int minLength = Math.min(firstLower.length(), secondLower.length());
				int charIndex = 0;
				while (charIndex < minLength && firstLower.charAt(charIndex) == secondLower.charAt(charIndex)) {
					charIndex++;
				}
				
				boolean firstComesAfterSecond;
				if(charIndex < minLength) {
					firstComesAfterSecond = firstLower.charAt(charIndex) >  secondLower.charAt(charIndex);
				}else {
					firstComesAfterSecond = firstLower.length() > secondLower.length();
				}
				
				if(firstComesAfterSecond) {
					Employee temp = empArr[firstIndex];
					empArr[firstIndex] = empArr[secondIndex];
					empArr[secondIndex] = temp;
				}
				
			}
		}
		
	}
	
	
	
//	private static void sortByNameBubbleSort(Employee[] empArr, int currIndex) {
//		
//		
//	}

}
