package org.rugom.employee;

import java.util.LinkedList;
import java.util.ListIterator;
import java.util.Scanner;
import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

//import org.rugom.utilities.ConsoleInput;
//import org.rugom.utilities.LinkedList;
public class Main {
	
	static Scanner sc = new Scanner(System.in);
	
	public static void main(String[] args) {
		
		//making the menu driven program
		int choice;
		
//		Scanner sc = new Scanner(System.in);
		
		Employee[] empArr = new Employee[60];
		LinkedList<Employee> empList = new LinkedList<>();
		ListIterator<Employee> listIterator = empList.listIterator();
		int currIndex = 0;
		
		do {
			System.out.println("Employee Operations: ");
			System.out.println("1.Add\n2.Delete\n3.Display\n4.Save\n5.Load\n6.Sort\n0.Exit");
			System.out.println("Enter your choice:");
			choice = sc.nextInt();
			if(currIndex > 60) {
				System.out.println("Organization is full no more employees can be added!!!");
				return;
			}
				
			
			switch(choice) {
			
				case 1:
					System.out.println("Select Employee Type:");
					System.out.println("1.Manager\n2.Engineer\n3.SalesPerson\n0.Exit");
					System.out.println("Type your choice: ");
					int empTypeSelectionChoice;
					do {
						empTypeSelectionChoice = sc.nextInt();
						
						switch(empTypeSelectionChoice) {
						case 1:{
							Employee emp = getEmployeeInput("Manager");
							empList.add(emp);
							break;
						}
						case 2:
						{
							Employee emp = getEmployeeInput("Engineer");
							empList.add(emp);
							break;
						}
						case 3: {
							Employee emp = getEmployeeInput("SalesPerson");
							empList.add(emp);
							break;
						}
						case 0:
							System.out.println("Exiting...");
							break;
						}
						break;
						
					}while(empTypeSelectionChoice != 0);
				case 2:
					
					break;
				case 3:
					
					int displayTypeChoice;
					do {
						System.out.println("Display Functions: ");
						System.out.println("1.All Employees\n2.Manager\n3.Engineer\n4.SalesPerson\n5.Display First Employee\n6.Previous Employee\n7.Next Employee\n8.Last Employee\n0.Exit to Main Menu");
						System.out.println("Enter your choice");
						displayTypeChoice= sc.nextInt();
						switch(displayTypeChoice) {
							case 1:{
																
								for(Employee emp : empList) {
									System.out.println(emp.displayEmployee());
								}
									
								break;
							}
							case 2:{
																					
								for(Employee emp : empList) {
									if(emp instanceof Manager)
									System.out.println(emp.displayEmployee());
								}
								break;
							}
							case 3:{
								
								for(Employee emp : empList) {
									if(emp instanceof Engineer)
									System.out.println(emp.displayEmployee());
								}
								break;
							}
							case 4:{
								for(Employee emp : empList) {
									if(emp instanceof SalesPerson)
									System.out.println(emp.displayEmployee());
								}
								break;
							}
							case 5: // Get First
							    if (!empList.isEmpty()) {
							        System.out.println(empList.getFirst().displayEmployee());
							        listIterator = empList.listIterator(0);
							    } else {
							        System.out.println("List is empty.");
							    }
							    break;

							case 6: // Previous Employee
							    if (listIterator.hasPrevious()) {
							        Employee prevEmp = listIterator.previous();
							        System.out.println(prevEmp.displayEmployee());
							    } else {
							        System.out.println("No previous employee. Already at the beginning.");
							    }
							    break;

							case 7: // Next Employee
							    if (listIterator.hasNext()) {
							        Employee nextEmp = listIterator.next();
							        System.out.println(nextEmp.displayEmployee());
							    } else {
							        System.out.println("No next employee. Already at the end.");
							    }
							    break;

							case 8: // Get Last
							    if (!empList.isEmpty()) {
							        System.out.println(empList.getLast().displayEmployee());
							        // Reset iterator to the end
							        listIterator = empList.listIterator(empList.size());
							    } else {
							        System.out.println("List is empty.");
							    }
							    break;
							case 0:
								break;
						}	
					}while(displayTypeChoice!=0);
					
					break;
				case 4:
					// SAVE
					try (FileOutputStream fileStream = new FileOutputStream("E:\\puneacts\\empData.txt");
					     ObjectOutputStream objFile = new ObjectOutputStream(fileStream)) {

					    for (Employee emp : empList) {
					        objFile.writeObject(emp);
					    }
					    System.out.println("Employee Objects Saved successfully in the file!");

					} catch (FileNotFoundException e) {
					    e.printStackTrace();
					} catch (IOException e) {
					    e.printStackTrace();
					}
					break;
				case 5:
					// LOAD
					try (FileInputStream fileStream = new FileInputStream("E:\\puneacts\\empData.txt");
					     ObjectInputStream objFile = new ObjectInputStream(fileStream)) {

					    empList.clear(); // Clear existing list before loading

					    while (true) {
					        try {
					            Employee emp = (Employee) objFile.readObject();
					            empList.add(emp);                               // Rebuild the LinkedList
					        } catch (EOFException e) {
					            break;                                          // End of file reached
					        }
					    }
					    System.out.println("Employee Objects Loaded successfully from the file!");

					} catch (FileNotFoundException e) {
					    e.printStackTrace();
					} catch (IOException | ClassNotFoundException e) {
					    e.printStackTrace();
					}
					break;
				case 6:
					//sort according to name ascending
					sortByNameBruteForce(empList);
					//sort using string compareto method
					sortByNameStringCompareTo(empArr, currIndex);
					break;
				case 0:
					System.out.println("Program is Exited!");
					break;
				default:
					System.out.println("Invalid Selection!!!");
					break;
			}
		}while(choice != 0);
		
	}
	
static Employee getEmployeeInput(String empType) {
		
		
		System.out.println("Enter the name of " + empType +": ");
		String name = sc.next();
		System.out.println("Enter the address of " + empType +": ");
		String address = sc.next();
		System.out.println("Enter the age of " + empType +": ");
		int age = sc.nextInt();
		System.out.println("Enter the gender of " + empType + ": ");
		boolean gender = sc.nextBoolean();
		System.out.println("Enter the Basic Salary of " + empType + ": ");
		float basicSalary = sc.nextFloat();
		
		
		if(empType == "Manager") {
			System.out.println("Enter the HRA of " + empType + ": ");
			float hra = sc.nextFloat();
			Manager emp = new Manager(name, address, age, gender, basicSalary);
			emp.setHra(hra);
			
			return emp;
		}else if(empType == "Engineer") {
			System.out.println("Enter the Overtime of " + empType + ": ");
			float overtime = sc.nextFloat();
			Engineer emp = new Engineer(name, address, age, gender, basicSalary);
			emp.setOvertime(overtime);	
			
			return emp;
		}else {
			System.out.println("Enter the Commission of " + empType + ": ");
			float commission = sc.nextFloat();
			SalesPerson emp = new SalesPerson(name, address, age, gender, basicSalary);
			emp.setCommission(commission);	
			
			return emp;
		}	
	}

	private static void sortByNameStringCompareTo(Employee[] empArr, int currIndex) {
		for(int i=0;i<currIndex-1;i++) {
			int indexOfFirstString = i;
			
			
			for(int j=i+1;j<currIndex;j++) {
				String firstString=empArr[indexOfFirstString].getName();
				String secondString=empArr[j].getName();
				
				
				if(secondString.compareToIgnoreCase(firstString)<0) {
				indexOfFirstString=j;
				
				
			}
		}
			if(indexOfFirstString !=i) {
				Employee temp=empArr[i];
				empArr[i]=empArr[indexOfFirstString];
				empArr[indexOfFirstString]=temp;
			}
		
		}
	}

	private static void sortByNameBruteForce(LinkedList<Employee> empList) {
	    int size = empList.size();

	    for (int firstIndex = 0; firstIndex < size - 1; firstIndex++) {
	        for (int secondIndex = firstIndex + 1; secondIndex < size; secondIndex++) {

	            String firstString = empList.get(firstIndex).getName();
	            String secondString = empList.get(secondIndex).getName();

	            String firstLower = firstString.toLowerCase();
	            String secondLower = secondString.toLowerCase();

	            int minLength = Math.min(firstLower.length(), secondLower.length());
	            int charIndex = 0;

	            while (charIndex < minLength && firstLower.charAt(charIndex) == secondLower.charAt(charIndex)) {
	                charIndex++;
	            }

	            boolean firstComesAfterSecond;
	            if (charIndex < minLength) {
	                firstComesAfterSecond = firstLower.charAt(charIndex) > secondLower.charAt(charIndex);
	            } else {
	                firstComesAfterSecond = firstLower.length() > secondLower.length();
	            }

	            if (firstComesAfterSecond) {
	                // Swap using set()
	                Employee temp = empList.get(firstIndex);
	                empList.set(firstIndex, empList.get(secondIndex));
	                empList.set(secondIndex, temp);
	            }
	        }
	    }
	    System.out.println("Sorted the Employee List Successfully!!!");
	}
//	private static void sortByNameBubbleSort(Employee[] empArr, int currIndex) {
//		
//		
//	}
	

}
