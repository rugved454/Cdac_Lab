package org.rugom.utilities;

public class Program {

	public static void main(String[] args) {
		
		final int MAX_EMPLOYEES=30;
		final int MENU_ADD_MANAGER=1;
		final int MENU_ADD_ENGINEER;
		final int MENU_DISPLAY_ALL;
		
		LinkedList<Employee> employeeList=new LinkedList<Employee>();
		
		int menuChoice=0;
		
		do {
			menuChoice=ConsoleInput.getInt();
			switch(menuChoice) {
			case MENU_ADD_EMPLOYEES: 
				
				break;
			case 1: 
				
				break;
			case 1: 
				
				break;
			case 1: 
				
				break;
			case 1: 
	
				break;
			case 1: 
	
				break;
			case 7: 
				System.out.println("Exiting program....");
				break;

			default:
				System.out.println("Invalid Choice");
			
			
			}
			
		}
		while(menuChoice!=7)
		
		
	}

}
