package org.rugom.utilities;

public class LLDemo {
	
	public static void main(String[] args) {
		
		//print all
			LinkedList<String> objList = new LinkedList<>();
			objList.add("Raju");
			objList.add("Ravi");
			objList.add("Raj");
			objList.add("Rahul");
			
     		String currString = objList.getFirst();	 //raju,ravi
			objList.delete(0);
			while(currString != null) {
				System.out.println(currString);
				currString = objList.getNext();
			}
			currString = objList.getFirst();	
	}
	
}
      