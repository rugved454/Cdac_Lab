package org.rugom.utilities;

public class LinkedList<T> {
		
	Node<T> start;
	Node<T> end;
	Node<T> current;
	int maxCount;	

	public void add(T data){
		Node<T> tempNode=new Node<T>(data);
		if(start==null) {
			start=current=end=tempNode;
		}
		else {
			end.next=tempNode;
			tempNode.previous=end;
			end=tempNode;
		}
		maxCount++;	
	}
	
	
	public void delete(int index) {
		if(start==null || index>maxCount-1)
			return;
		if (start==end)
			start=end=current=null;
		
		else if(index==0)
		{
			start=start.next;
			start.previous=null;
			current=start;
		}
		else if(index==maxCount-1) {
			end=end.previous;
			end.next=null;
			current=start;
		}
		else {
			Node<T> tempNode=start;
			for(int temp=0;temp<index;temp++) {
				tempNode=tempNode.next;
			}	
			tempNode.next.previous=tempNode.previous;
			tempNode.previous.next=tempNode.next;
		}
		maxCount--;
	}

	
	public T getFirst() {
		if(start==null)
			return null;
		current=start;
		return current.data;
		
	}
	
	
	public T getLast() {
		if(start==null)
			return null;
		current=end;
		return current.data;
		
	}
	
	
	public T getNext() {
		if(start==null ||current.next==null)
			return null;
		else {
			current=current.next;
			return current.data;
		}
	
	}
	
	
	public T getPrevious() {
		if(start==null ||current.previous==null)
			return null;
		else {
			current=current.previous;
			return current.data;
		}
	}
	
	
}
