package org.rugom.utilities;
public class ConsoleInput {
	public static String getInput() {
	try {
	byte[] arrinput= new byte[100];
	int length=System.in.read(arrinput);
	byte[] arrfinal = new byte[length-2];
	System.arraycopy(arrinput,0,arrfinal,0,length-2);
	String objstring=new String(arrfinal);
	return objstring;
	}
	catch(Exception e ) {
		e.printStackTrace();
		return null;
	}
	
	}
	
	public static int getInt() {
		String objstring=getInput();
		int value= Integer.parseInt(objstring);
		return value;
	}
	
	public static float getFloat() {
		String objstring=getInput();
		float value= Float.parseFloat(objstring);
		return value;
	}
	
	public static boolean getBoolean() {
		String objstring=getInput();
		boolean value= Boolean.parseBoolean(objstring);
		return value;
	}
}

