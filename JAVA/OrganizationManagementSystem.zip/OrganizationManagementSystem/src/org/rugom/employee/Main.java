package org.rugom.employee;

import org.rugom.utilities.ConsoleInput;

public class Main {
	
	static Employee getEmployeeInput(String empType) {
		
		System.out.println("Enter the name of " + empType +": ");
		String name = ConsoleInput.getInput();
		System.out.println("Enter the address of " + empType +": ");
		String address = ConsoleInput.getInput();
		System.out.println("Enter the age of " + empType +": ");
		int age = ConsoleInput.getInt();
		System.out.println("Enter the gender of " + empType + ": ");
		boolean gender = ConsoleInput.getBoolean();
		System.out.println("Enter the Basic Salary of " + empType + ": ");
		float basicSalary = ConsoleInput.getFloat();
		
		
		if(empType == "Manager") {
			System.out.println("Enter the HRA of " + empType + ": ");
			float hra = ConsoleInput.getFloat();
			Manager emp = new Manager(name, address, age, gender, basicSalary);
			emp.setHra(hra);
			return emp;
		}else if(empType == "Engineer") {
			System.out.println("Enter the Overtime of " + empType + ": ");
			float overtime = ConsoleInput.getFloat();
			Engineer emp = new Engineer(name, address, age, gender, basicSalary);
			emp.setOvertime(overtime);	
			return emp;
		}else {
			System.out.println("Enter the Commission of " + empType + ": ");
			float commission = ConsoleInput.getFloat();
			SalesPerson emp = new SalesPerson(name, address, age, gender, basicSalary);
			emp.setCommission(commission);	
			return emp;
		}	
	}
	
	public static void main(String[] args) {
		
		//making the menu driven program
		int choice;
		
		Employee[] empArr = new Employee[60];
		int currIndex = 0;
		
		do {
			System.out.println("1.Add\n2.Delete\n3.Display\n4.Save\n5.Load\n6.Sort\n0.Exit");
			System.out.println("Enter your choice:");
			choice = ConsoleInput.getInt();
			if(currIndex > 60) {
				System.out.println("Organization is full no more employees can be added!!!");
				return;
			}
				
			
			switch(choice) {
			
				case 1:
					System.out.println("1.Manager\n2.Engineer\n3.SalesPerson\n0.Exit");
					System.out.println("Select Employee Type:");
					int empTypeSelectionChoice;
					do {
						empTypeSelectionChoice = ConsoleInput.getInt();
						
						switch(empTypeSelectionChoice) {
						case 1:{
							Employee emp = getEmployeeInput("Manager");
							empArr[currIndex++] = emp;
							break;
						}
						case 2:
						{
							Employee emp = getEmployeeInput("Engineer");
							empArr[currIndex++] = emp;
							break;
						}
						case 3: {
							Employee emp = getEmployeeInput("SalesPerson");
							empArr[currIndex++] = emp;
							break;
						}
						case 0:
							System.out.println("Exiting...");
							break;
						}
						break;
						
					}while(empTypeSelectionChoice != 0);
				case 2:
					
					break;
				case 3:
					
					int displayTypeChoice;
					do {
						System.out.println("1.All\n2.Manager\n3.Engineer\n4.SalesPerson\n0.Exit");
						displayTypeChoice=ConsoleInput.getInt();
						switch(displayTypeChoice) {
							case 1:{
								for(int i = 0; i < currIndex; i++) {
									System.out.println(empArr[i].displayEmployee());
								}
								break;
							}
							case 2:{
								for(int i = 0; i<currIndex; i++) {									
									if(empArr[i] instanceof Manager) {
										System.out.println(empArr[i].displayEmployee());
									}
								}
								break;
							}
							case 3:{
								for(int i = 0; i<currIndex; i++) {									
									if(empArr[i] instanceof Engineer) {
										System.out.println(empArr[i].displayEmployee());
									}
								}
								break;
							}
							case 4:{
								for(int i = 0; i<currIndex; i++) {									
									if(empArr[i] instanceof SalesPerson) {
										System.out.println(empArr[i].displayEmployee());
									}
								}
								break;
							}
							case 0:
								break;
						}	
					}while(displayTypeChoice!=0);
					
					break;
				case 4:
					break;
				case 5:
					break;
				case 6:
					break;
				case 7:
					System.out.println("Exiting....");
					break;
				default:
					System.out.println("Invalid Selection!!!");
					break;
			
			}
		}while(choice != 0);
		
	}

}
