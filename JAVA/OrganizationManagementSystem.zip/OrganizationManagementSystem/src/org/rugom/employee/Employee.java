package org.rugom.employee;

public sealed class Employee permits Manager,Engineer,SalesPerson {
	
	protected String name;
	protected String address;
	protected int age;
	protected boolean gender;
	protected float basicSalary;
	
	public Employee(String name, String address, int age, boolean gender, float basicSalary) {
//		super();
		this.name = name;
		this.address = address;
		this.age = age;
		this.gender = gender;
		this.basicSalary = basicSalary;
	}

	String getName() {
		return name;
	}

	void setName(String name) {
		if(name.length() > 3 && name.length() < 20)
			this.name = name;
		else this.name = "employee";
	}

	String getAddress() {
		return address;
	}

	void setAddress(String address) {
		this.address = address;
	}

	int getAge() {
		return age;
	}

	void setAge(int age) {
		if(age > 18 && age < 70)
			this.age = age;
		else this.age = 18;
	}

	boolean isGender() {
		return gender;
	}

	void setGender(boolean gender) {
		this.gender = gender;
	}

	float getBasicSalary() {
		if(basicSalary < 0) basicSalary = 1000;
		return basicSalary;
	}

	void setBasicSalary(float basicSalary) {
		this.basicSalary = basicSalary;
	}
	
	//getters and setters
	
	
	//methods
	
	String displayEmployee() {
		StringBuffer sbuf = new StringBuffer();
		
		sbuf.append("Name: ");
		sbuf.append(getName());
		sbuf.append("\n");
		sbuf.append("Address: ");
		sbuf.append(getAddress());
		sbuf.append("\n");
		sbuf.append("Age: "); 
		sbuf.append(getAge());
		sbuf.append("\n");
		sbuf.append("Gender: ");
		sbuf.append(((isGender() == true) ? "Male" : "Female"));
		sbuf.append("\n");
		sbuf.append("Basic Salary: ");
		sbuf.append(getBasicSalary());
		
		
		return sbuf.toString();
	}
	
	
	
	

}
