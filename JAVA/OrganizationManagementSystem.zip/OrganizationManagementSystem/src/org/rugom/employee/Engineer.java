package org.rugom.employee;

public final class Engineer extends Employee {
	private float overtime;
	public Engineer(String name, String address, int age, boolean gender, float basicSalary) {
		super(name, address, age, gender, basicSalary);
		overtime = 0.0f;
		
	}
	public float getOvertime() {
		return overtime;
	}
	public void setOvertime(float overtime) {
		this.overtime = overtime;
	}
	
	@Override
	String displayEmployee() {
		StringBuffer sbuf = new StringBuffer();
		sbuf.append("----------------------");
		sbuf.append("\n");
		sbuf.append("Engineer");
		sbuf.append("\n");
		sbuf.append(super.displayEmployee());
		sbuf.append("\n");
		sbuf.append("Overtime Rs : ");
		sbuf.append(overtime);
		sbuf.append("\n");
		sbuf.append("Total Salary: ");
		sbuf.append(overtime + basicSalary);
		sbuf.append("\n");
		sbuf.append("----------------------");
		sbuf.append("\n");
		return sbuf.toString();
	}
	
}
