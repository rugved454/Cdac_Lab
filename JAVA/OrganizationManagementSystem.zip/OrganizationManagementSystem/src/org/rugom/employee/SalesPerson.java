package org.rugom.employee;

public final class SalesPerson extends Employee {
	
	private float commission;

	public SalesPerson(String name, String address, int age, boolean gender, float basicSalary) {
		super(name, address, age, gender, basicSalary);
		commission = 0.0f;
		
	}

	public float getCommission() {
		return commission;
	}

	public void setCommission(float commission) {
		this.commission = commission;
	}
	
	@Override
	String displayEmployee() {
		StringBuffer sbuf = new StringBuffer();
		sbuf.append("----------------------");
		sbuf.append("\n");
		sbuf.append("SalesPerson");
		sbuf.append("\n");
		sbuf.append(super.displayEmployee());
		sbuf.append("\n");
		sbuf.append("Commission : ");
		sbuf.append(commission);
		sbuf.append("\n");
		sbuf.append("Total Salary: ");
		sbuf.append(commission + basicSalary);
		sbuf.append("\n");
		sbuf.append("----------------------");
		sbuf.append("\n");
		return sbuf.toString();
	}
	

}
