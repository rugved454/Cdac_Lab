package org.rugom.employee;

public final class Manager extends Employee {
	
	private float hra;

	public Manager(String name, String address, int age, boolean gender, float basicSalary) {
		super(name, address, age, gender, basicSalary);
		hra = 0.0f;
		
	}

	public float getHra() {
		return hra;
	}

	public void setHra(float hra) {
		this.hra = hra;
	}
	@Override
	String displayEmployee() {
		StringBuffer sbuf = new StringBuffer();
		sbuf.append("----------------------");
		sbuf.append("\n");
		sbuf.append("Manager");
		sbuf.append("\n");
		sbuf.append(super.displayEmployee());
		sbuf.append("\n");
		sbuf.append("hra: ");
		sbuf.append(hra);
		sbuf.append("\n");
		sbuf.append("Total Salary: ");
		sbuf.append(hra + basicSalary);
		sbuf.append("\n");
		sbuf.append("----------------------");
		sbuf.append("\n");
		return sbuf.toString();
	}

}
