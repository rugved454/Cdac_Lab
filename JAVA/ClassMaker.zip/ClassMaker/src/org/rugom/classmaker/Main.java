package org.rugom.classmaker;

import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;
import java.io.FileWriter;
import java.io.IOException;

public class Main {

    static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {

        System.out.println("Welcome to the POJO Class Generator");
        System.out.println("------------------------------------");

        System.out.print("\nEnter package name: ");
        String packageName = scanner.nextLine().trim();

        System.out.print("Enter class name: ");
        String className = scanner.nextLine().trim();

        System.out.print("Enter access specifier for the class (public / default): ");
        String classAccessInput = scanner.nextLine().trim();

        String classAccessStr;
        if (classAccessInput.equalsIgnoreCase("default")) {
            classAccessStr = "";
        } else {
            classAccessStr = "public";
        }

        System.out.print("\nHow many fields does the class have? ");
        int fieldCount = Integer.parseInt(scanner.nextLine().trim());

        List<String[]> fields = new ArrayList<>();

        for (int i = 1; i <= fieldCount; i++) {
            System.out.println("\nField " + i + ":");
            System.out.print("  Data type (e.g. int, String): ");
            String dataType = scanner.nextLine().trim();
            System.out.print("  Field name (e.g. studentName): ");
            String fieldName = scanner.nextLine().trim();
            fields.add(new String[]{dataType, fieldName});
        }

        List<String[]> methods = new ArrayList<>();

        System.out.print("\nDo you want to add any methods? (yes/no): ");
        String addMethodsAnswer = scanner.nextLine().trim();

        while (addMethodsAnswer.equalsIgnoreCase("yes")) {

            System.out.println("\nNew Method:");

            System.out.print("  Access specifier (public/private/protected): ");
            String mAccess = scanner.nextLine().trim();

            System.out.print("  Return type (e.g. void, int, String): ");
            String mReturnType = scanner.nextLine().trim();

            System.out.print("  Method name (e.g. calculateTotal): ");
            String mName = scanner.nextLine().trim();

            System.out.print("  Number of parameters: ");
            int paramCount = Integer.parseInt(scanner.nextLine().trim());

            String params = "";
            for (int p = 1; p <= paramCount; p++) {
                System.out.print("\n  Parameter " + p + " type: ");
                String pType = scanner.nextLine().trim();
                System.out.print("  Parameter " + p + " name: ");
                String pName = scanner.nextLine().trim();
                if (p > 1) params = params + ", ";
                params = params + pType + " " + pName;
            }

            methods.add(new String[]{mAccess, mReturnType, mName, params});

            System.out.print("\nAdd another method? (yes/no): ");
            addMethodsAnswer = scanner.nextLine().trim();
        }

        String content = "";

        content = content + "package " + packageName + ";\n\n";

        if (classAccessStr.isEmpty()) {
            content = content + "class " + className + " {\n\n";
        } else {
            content = content + classAccessStr + " class " + className + " {\n\n";
        }

        for (String[] field : fields) {
            content = content + "    private " + field[0] + " " + field[1] + ";\n";
        }

        content = content + "\n";

        content = content + "    public " + className + "() {\n";
        content = content + "    }\n\n";

        if (!fields.isEmpty()) {
            content = content + "    public " + className + "(";

            for (int i = 0; i < fields.size(); i++) {
                if (i > 0) content = content + ", ";
                content = content + fields.get(i)[0] + " " + fields.get(i)[1];
            }

            content = content + ") {\n";

            for (String[] field : fields) {
                content = content + "        this." + field[1] + " = " + field[1] + ";\n";
            }

            content = content + "    }\n\n";
        }

        for (String[] field : fields) {
            String type = field[0];
            String name = field[1];
            String cap = Character.toUpperCase(name.charAt(0)) + name.substring(1);

            if (type.equals("boolean")) {
                content = content + "    public boolean is" + cap + "() {\n";
                content = content + "        return " + name + ";\n";
                content = content + "    }\n\n";
            } else {
                content = content + "    public " + type + " get" + cap + "() {\n";
                content = content + "        return " + name + ";\n";
                content = content + "    }\n\n";
            }
        }

        for (String[] field : fields) {
            String type = field[0];
            String name = field[1];
            String cap = Character.toUpperCase(name.charAt(0)) + name.substring(1);

            content = content + "    public void set" + cap + "(" + type + " " + name + ") {\n";
            content = content + "        this." + name + " = " + name + ";\n";
            content = content + "    }\n\n";
        }

        for (String[] method : methods) {
            content = content + "    " + method[0] + " " + method[1] + " " + method[2] + "(" + method[3] + ") {\n";
            content = content + "    }\n\n";
        }

        content = content + "}\n";

        String fileName = className + ".java";

        try (FileWriter writer = new FileWriter(fileName)) {
            writer.write(content);
            System.out.println("\nFile " + fileName + " created successfully!");
        } catch (IOException e) {
            System.out.println("Error: " + e.getMessage());
        }

        System.out.println("\n--- Preview ---\n");
        System.out.println(content);

        scanner.close();
    }
}