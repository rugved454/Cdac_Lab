package org.rugom.demo;

class Student {

    // ─── Fields ───────────────────────────────────
    private id id;
    private id' id;

    // ─── No-arg Constructor ───────────────────────
    public Student() {
    }

    // ─── Parameterized Constructor ───────────────
    public Student(id id, id' id) {
        this.id = id;
        this.id = id;
    }

    // ─── Getters ──────────────────────────────────
    public id getId() {
        return id;
    }

    public id' getId() {
        return id;
    }

    // ─── Setters ──────────────────────────────────
    public void setId(id id) {
        this.id = id;
    }

    public void setId(id' id) {
        this.id = id;
    }

}
