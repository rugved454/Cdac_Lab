package org.rugom.singlyLinkedList;

public class Multiply_Recursion {
	
	public static int multiply(int a, int b) {
		
		if(a == 0 || b == 0) return 0;
			
			a = Math.abs(a);
			b = Math.abs(b);
			
			return a + multiply(a, b - 1);
		
	}
	
	public static void main(String[] args) {
		
		System.out.println(multiply(-70000,-6));
		
		
	}

}
