package org.rugom.singlyLinkedList;

public class SinglyLinkedList {

	Node head = null;
	Node tail = null;
	private int size = 0;

	public void addToFront(int element) {
		Node newNode = new Node();
		newNode.data = element;
		newNode.next = null;

		if (head == null) {
			head = newNode;
			tail = head;
			size++;
			return;
		}

		newNode.next = head;
		head = newNode;
		size++;
	}

	public void addToIndex(int element, int index) {

		if (index > size) {
			System.out.println(index + " is a Wrong index");
			return;
		}

		Node newNode = new Node();
		newNode.data = element;
		newNode.next = null;

		Node current = head;
		int count = 0;

		if (index == 0) {
			newNode.next = head;
			head = newNode;
			size++;
			return;
		}

		while (count != index - 1) {
			if (current.next == null) {
				if (index - count == 1) {
					current.next = newNode;
					tail = newNode;
				}
			}
			current = current.next;
			count = count + 1;
		}
		newNode.next = current.next;
		current.next = newNode;
		size++;

	}

	public void addToEnd(int element) {
		Node newNode = new Node();
		newNode.data = element;
		newNode.next = null;

		if (head == null) {
			head = newNode;
			tail = head;
			size++;
			return;
		}

		tail.next = newNode;
		tail = newNode;
		size++;
	}

	public void printList() {
		Node current = head;

		while (current != null) {
			System.out.print(current.data + "->");
			current = current.next;
		}
		System.out.println(current);
		System.out.println();
	}

	public int getSize() {
		return size;
	}

	void delete(int element) {

		if (head == null)
			return;

		Node current = head;
		if (current.data == element) {
			head = head.next;
			size--;
			return;
		}

		while (current.next != null) {
			if (current.next.data == element) {
				current.next = current.next.next;
				size--;
				return;
			}

			current = current.next;
		}
	}

	void deleteAll(int element) {

//		Node current = head;
//
//		while (current != null) {
//			delete(element);
//			current = current.next;
//		}
		
		
		if (head == null)
			return;

		Node current = head;
		if (current.data == element) {
			head = head.next;
			size--;
		}

		while (current.next != null) {
			if (current.next.data == element) {
				current.next = current.next.next;
				size--;
			}

			current = current.next;
		}
	}

	boolean search(int element) {
		return true;
	}

}
