package org.rugom.singlyLinkedList;

public class Main {
	
	public static void main(String[] args) {
		
		SinglyLinkedList sList = new SinglyLinkedList();
		
//		sList.addToFront(5);
//		sList.addToFront(6);
//		sList.addToFront(7);
		
		sList.addToFront(70);
		sList.addToFront(70);
		sList.addToFront(70);
		sList.addToFront(90);
		sList.addToFront(80);
		sList.addToFront(70);
		sList.addToFront(10);
		
		sList.deleteAll(70);
		
//		sList.addToPosition(4, 6);
//		sList.addToPosition(6,7);
		sList.printList();
		
		System.out.println("SIZE: " + sList.getSize());
	}

}
