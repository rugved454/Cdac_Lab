package org.rugom.singlyLinkedList;

public class Node {
	
	public int data;
	public Node next;
	

}
