package org.rugom.arroperations;

import java.util.Arrays;

public class LinearQueue<T> implements Queue<T> {

	private int front;
	private int rear;
	private T[] queueData;

	@SuppressWarnings("unchecked")
	public LinearQueue(int capacity) {
		if (capacity <= 0) {
            throw new IllegalArgumentException("capacity must be > 0");
        }
        queueData = (T[]) new Object[capacity];
		front = -1;
		rear = -1;
	}

	@Override
	public void enqueue(T element) {
		try {
			if(isFull()) {
				throw new Exception("Queue is Full!!!");
			}
			
			if(isEmpty()) {
				front = 0;
				rear = 0;
			}else {
				rear = rear + 1;				
			}
			queueData[rear] = element;
			
			
		}catch (Exception e) {
			e.printStackTrace();
			return;
		}
		
		
	}

	@Override
	public T dequeue() {
		
		try {
			if(isEmpty()) {
				throw new Exception("Queue is Empty!!!");
			}
			T result = queueData[front];
			
			for(int i = front; i < rear; i++) {
				queueData[i] = queueData[i + 1];
			}
			
			queueData[rear] = null;
			rear--;
			
			if(rear < front) {
				front = -1;
				rear = -1;
			}
			
			return result;
			
			
			
		}catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		
	}

	@Override
	public boolean isEmpty() {
		return front == -1;
	}

	@Override
	public boolean isFull() {
		return rear == queueData.length - 1;
	}
	
	public void printQueue() {
		System.out.println(Arrays.toString(queueData));
	}

}
