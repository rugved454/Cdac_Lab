"""
make_doc.py
Automatically scans the folder where this script is located for:
  - .java files
  - matching image files (same name, or with "(1)", "(2)" suffix)
and builds a single Word document pairing each java file with its screenshot(s).

Just place this script in the same folder as your .java files and images,
then run: python make_doc.py
"""

import os
import re
from docx import Document
from docx.shared import Inches, Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH
from PIL import Image

# =================== CONFIGURATION ===================
# Automatically get the folder where this script is located
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
SOURCE_DIR = SCRIPT_DIR
OUTPUT_DOCX = os.path.join(SCRIPT_DIR, "Final.docx")

CODE_EXTENSIONS = {".java"}
IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".gif", ".bmp"}

SORT_BY = "name"        # "name" = alphabetical, "mtime" = file modified time
FONT_NAME = "Consolas"  # monospace font for code
FONT_SIZE = 9
MAX_IMG_WIDTH_INCHES = 6.0
# =======================================================


def strip_dup_suffix(name: str) -> str:
    """Remove a trailing ' (1)', ' (2)', etc. from a filename (without extension)."""
    return re.sub(r"\s*\(\d+\)$", "", name)


def get_base_name(filename: str) -> str:
    name, _ = os.path.splitext(filename)
    return strip_dup_suffix(name)


def find_matching_images(code_base: str, image_files: list) -> list:
    """Return all images whose base name (stripped of (n)) matches code_base,
    sorted so the un-numbered image comes first, then (1), (2), ..."""
    matches = []
    for img in image_files:
        img_name = os.path.splitext(img)[0]
        if strip_dup_suffix(img_name) == code_base:
            matches.append(img)

    def sort_key(fname):
        name = os.path.splitext(fname)[0]
        m = re.search(r"\((\d+)\)$", name)
        return int(m.group(1)) if m else 0

    matches.sort(key=sort_key)
    return matches


def read_code_file(path: str) -> str:
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            return f.read()
    except Exception as e:
        return f"[ERROR READING FILE: {e}]"


def add_code_block(doc: Document, code_text: str):
    para = doc.add_paragraph()
    para.paragraph_format.space_after = Pt(0)
    lines = code_text.split("\n")
    for i, line in enumerate(lines):
        run = para.add_run(line)
        run.font.name = FONT_NAME
        run.font.size = Pt(FONT_SIZE)
        if i != len(lines) - 1:
            run.add_break()


def add_image(doc: Document, img_path: str):
    try:
        with Image.open(img_path):
            pass  # just verifying the image opens correctly
        para = doc.add_paragraph()
        para.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = para.add_run()
        run.add_picture(img_path, width=Inches(MAX_IMG_WIDTH_INCHES))
    except Exception as e:
        err_para = doc.add_paragraph()
        err_run = err_para.add_run(f"[ERROR INSERTING IMAGE '{os.path.basename(img_path)}': {e}]")
        err_run.italic = True


def main():
    print(f"Scanning folder: {SOURCE_DIR}")

    all_files = [f for f in os.listdir(SOURCE_DIR)
                 if os.path.isfile(os.path.join(SOURCE_DIR, f))]

    image_files = [f for f in all_files
                   if os.path.splitext(f)[1].lower() in IMAGE_EXTENSIONS]

    code_files = [f for f in all_files
                  if os.path.splitext(f)[1].lower() in CODE_EXTENSIONS]

    if not code_files:
        print("No .java files were found in this folder.")
        return

    print(f"Found {len(code_files)} .java file(s) and {len(image_files)} image(s).")

    if SORT_BY == "mtime":
        code_files.sort(key=lambda f: os.path.getmtime(os.path.join(SOURCE_DIR, f)))
    else:
        code_files.sort()

    doc = Document()
    doc.add_heading("Java Code and Screenshots", level=0)

    for idx, cfile in enumerate(code_files, start=1):
        cpath = os.path.join(SOURCE_DIR, cfile)
        base_name = get_base_name(cfile)

        doc.add_heading(f"{idx}. {cfile}", level=1)

        code_text = read_code_file(cpath)
        add_code_block(doc, code_text)

        doc.add_paragraph()  # spacer

        matched_images = find_matching_images(base_name, image_files)
        if not matched_images:
            warn = doc.add_paragraph()
            r = warn.add_run(f"[No matching image found for '{cfile}']")
            r.italic = True
        else:
            for img in matched_images:
                add_image(doc, os.path.join(SOURCE_DIR, img))
                print(f"  -> Inserted image: {img}")

        doc.add_page_break()

    doc.save(OUTPUT_DOCX)
    print(f"\nDone! Document saved to:\n  {OUTPUT_DOCX}")


if __name__ == "__main__":
    main()