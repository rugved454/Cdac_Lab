package org.rugom.arroperations;

public class Program1 {
	static int arrSize = 0;

	public static int[] resize(int[] arr, int size) throws Exception {

		int[] newArr = new int[size];

		for (int i = 0; i < arrSize; i++) {
			newArr[i] = arr[i];
		}
		return newArr;

	}

	public static void insert(int[] arr, int element, int position) {
		if (position < 0 || position > arrSize) {
			System.out.println("Invalid INput!!!");
			return;
		}

		if (arrSize == arr.length) {
			System.out.println("Array is full!");
			return;
		}

		if (position == arrSize) {
			arrSize++;
			arr[arrSize - 1] = element;

		}
		for (int i = arrSize - 1; i >= position; i--) {
			arr[i + 1] = arr[i];
		}
		arr[position] = element;

		arrSize++;

	}

	public static void delete(int[] arr, int position) {

		if (position < 0 || position >= arrSize) {
			System.out.println("Invalid position!");
			return;
		}

		for (int i = position; i < arrSize - 1; i++) {
			arr[i] = arr[i + 1];
		}
		arr[arrSize - 1] = 0;
		arrSize--;

	}

	public static void main(String[] args) throws Exception {

		int[] arr = new int[100]; // physical size

		// manual inputs
//		for(int i = 0; i < 3; i++) {
//			System.out.println("Enter the element "+ i+ "th value" );
//			a
//			arrSize++;
//		}

		arr[0] = 1;
		arr[1] = 2;
		arr[2] = 3;
		arr[3] = 4;
		arr[4] = 5;

		arrSize = 5;

		// Resizing arr
		int[] newArr = resize(arr, 10);
		System.out.println(newArr.length);

		// insert (element, position)
		insert(arr, 7, 1);
//		insert(arr, 7, arrSize);

		// delete
		delete(arr, 2);

		for (int i = 0; i < arrSize; i++) {
			System.out.println(arr[i]);
		}

	}

}
