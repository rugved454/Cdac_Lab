package org.rugom.arroperations;

import java.util.Arrays;

public class FixedSizedStack implements Stack {

	private int[] stackData;
	private int top;

	public FixedSizedStack(int n) {
		stackData = new int[n];
		top = -1;
	}

	@Override
	public void push(int element) throws Exception {
		if (isFull()) {
			throw new Exception("Stack is Full, no more elements can be added!!!");
		}

		top = top + 1;
		stackData[top] = element;

	}

	@Override
	public int pop() throws Exception {
		if (isEmpty()) {
			throw new Exception("Stack is Empty, cannot pop!");
		}
		int result = stackData[top];
		top = top - 1;
		return result;
	}

	@Override
	public int peek() {
		return top;
	}

	@Override
	public boolean isEmpty() {
		if (top == -1)
			return true;
		return false;
	}

	@Override
	public boolean isFull() {
		if (top == (stackData.length - 1))
			return true;
		return false;
	}

	public void printStack() {
		System.out.println(Arrays.toString(stackData));
	}

	public Stack resizeStack(Stack oldStack, int size) throws Exception {
		if (size < stackData.length)
			return null;
		Stack newStack = new FixedSizedStack(size);

		for (int i = 0; i < stackData.length; i++) {
			newStack.push(stackData[i]);
		}
		return newStack;

	}
}
