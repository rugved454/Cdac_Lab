package org.rugom.arroperations;

public class Program2  {
	public static void main(String[] args) throws Exception {
	
		FixedSizedStack stack = new FixedSizedStack(4);
		stack.push(10);
		stack.push(5);
		stack.push(16);
		stack.push(20);
		System.out.println(stack.pop());
		
		stack.printStack();
		
	}
	
}
