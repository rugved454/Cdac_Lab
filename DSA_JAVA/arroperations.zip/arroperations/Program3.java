package org.rugom.arroperations;

//Q3. Define Queue as ADT (Refer to class notes).
//Abstract Data Type

public class Program3 {

	public static void main(String[] args) {
		LinearQueue<Integer> intQueue = new LinearQueue<>(3);
		LinearQueue<String> strQueue = new LinearQueue<>(3);
		
		
		//Integer queue checking
		intQueue.enqueue(10);
		intQueue.enqueue(20);
		intQueue.enqueue(30);
		System.out.println(intQueue.dequeue());
		System.out.println(intQueue.dequeue());
//		System.out.println(intQueue.dequeue());
		
		intQueue.printQueue();
		
		
		
		//String queue checking
		
		strQueue.enqueue("Raj");
		strQueue.enqueue("Ravi");
		strQueue.enqueue("Raju");
		System.out.println(strQueue.dequeue());
		System.out.println(strQueue.dequeue());
//		System.out.println(strQueue.dequeue());
		
		strQueue.printQueue();
	}
}
