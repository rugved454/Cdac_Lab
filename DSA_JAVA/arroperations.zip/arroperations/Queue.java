package org.rugom.arroperations;

public interface Queue<T> {
	
	void enqueue(T element);
	T dequeue();
	boolean isEmpty();
	boolean isFull();
	
}


