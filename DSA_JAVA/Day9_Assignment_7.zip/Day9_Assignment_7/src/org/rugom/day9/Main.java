//	Assignment
//	1. Implement the following function to sort the given array in descending order, using Bubble Sort
//	void bubbleSort(int[] arr);
//	Use the algorithm described in class to start from left side of array, to move smallest element towards the right end.
//
//	2. Implement the following function to sort the given array in descending order, using Insertion Sort
//	void insertionSort(int[] arr);
//
//	3. Implement the following function to check if given array elements are sorted or not.
//	boolean isArraySorted(int[] arr);
//	Hint: Use logic used in bubble sort.
//
//	4. Implement following function to sort the given array in descending order, using quick sort
//	public void quickSort(int[] arr)
//
//
//
//	Exercise 1: Implement the above algorithms to sort elements in descending order.
//
//	Exercise 2: Implement Bubble Sort to start from right end of array, to bring appropriate element towards the left side.
//
//	Exercise 3: Implement the algorithm to merge two sorted arrays. Use the following link to test your code.
//	https://leetcode.com/problems/merge-sorted-array
//
//	Exercise 4: Implement the algorithm to merge two sorted linked lists. Use the following link to test your code.
//	https://leetcode.com/problems/merge-two-sorted-lists
//
//
//
//
//
//	- OpenJDK
//	https://openjdk.org/
//
//	- Github repo of OpenJDK implementation.
//	https://github.com/openjdk/jdk
//
//	- Location of source code for java.util classes.
//	https://github.com/openjdk/jdk/tree/master/src/java.base/share/classes/java/util
package org.rugom.day9;

public class Main {

	static void bubbleSort(int[] arr) {

		int count = 0;
		int swapCount = 0;
		int n = arr.length;
		while (n > 1) { // n is index of outer loop
			int left = 0; // this is index of inner loop
			while (left < (n - 1)) {
				count = count + 1;
				if (arr[left] > arr[left + 1]) {
					swapCount = swapCount + 1;
					swap(arr, left, left + 1);
				}
				left = left + 1;
			}
			n = n - 1;
		}
		System.out.println("Count = " + count + ", Swap count = " + swapCount);
	}

	static void swap(int[] arr, int idx1, int idx2) {
		int temp = arr[idx1];
		arr[idx1] = arr[idx2];
		arr[idx2] = temp;
	}

	static void selectionSort(int[] arr) {
		int elementPos = 0;
		int count = 0;
		int swapCount = 0;
		while (elementPos < arr.length - 1) {
			int smallestElementPos = elementPos;
			int i = elementPos + 1;
			while (i < arr.length) {
				count++;
				if (arr[i] < arr[smallestElementPos]) {
					smallestElementPos = i;
				}
				i++;
			}
			if (elementPos != smallestElementPos) {
				swapCount++;
				swap(arr, elementPos, smallestElementPos);
			}
			elementPos++;
		}
		System.out.println("Count = " + count + ", swap count = " + swapCount);
	}

	static void insertionSort(int[] arr) {
		int sortedSize = 1;
		int count = 0;

		while (sortedSize < arr.length) {
			int insertElement = arr[sortedSize];
			int currentIdx = sortedSize - 1;
			while (currentIdx >= 0) {
				count++;
				if (insertElement < arr[currentIdx]) {
					arr[currentIdx + 1] = arr[currentIdx];
				} else {
					break;
				}
				currentIdx--;
			}
			arr[currentIdx + 1] = insertElement;
			sortedSize++;
		}

		System.out.println("Count = " + count);
	}

	static boolean isArraySorted(int[] arr) {
		for (int i = 0; i < arr.length - 1; i++) {
			if (arr[i] > arr[i + 1])
				return false;
		}
		return true;
	}

	static public int partition(int[] arr,int startPos,int endPos) {
		int pivotPos=startPos;
		int left=startPos+1;
		int right=endPos;
		
		while(left<=right) {
			while(left<=right && arr[left]>=arr[pivotPos]) {
			left++;
			}
			while(left<=right && arr[pivotPos]>arr[right]) {
			right--;
			}
			if(left<right) {
			swap(arr,left,right);
				}
		
		}
		
		swap(arr,pivotPos,right);
		
		return right;
		
		}

	static public void quickSort(int[] arr,int startPos,int endPos) {
		
		if(startPos>=endPos) return;
		
		int pivotPos=partition(arr,startPos,endPos);
		quickSort(arr,startPos,pivotPos-1);
		quickSort(arr,pivotPos+1,endPos);
	}

	static public void printArray(int[] arr) {

		for (int i = 0; i < arr.length; i++) {
			System.out.print(arr[i] + " ");
		}
		System.out.println();
	}

	public static void main(String[] args) {

		int[] arr = new int[] { 5, 8, 9, 2, 3, 1, 4 };

//		bubbleSort(arr);
//		selectionSort(arr);
//		insertionSort(arr);
		quickSort(arr,0,arr.length-1);
//		
		printArray(arr);
		System.out.println(isArraySorted(arr));
	}

}
