package org.rugom.binarytree;

import java.util.Scanner;

public class Main {

    static Scanner scanner = new Scanner(System.in);

    // Recursively builds the tree and returns the fully connected node
    public static BTNode buildTree() {
        System.out.println("Enter data for the node:");
        int data = scanner.nextInt();
        BTNode node = new BTNode(data);

        System.out.println("Does node " + data + " have a LEFT child? (y/n)");
        String left = scanner.next();
        if (left.equalsIgnoreCase("y")) {
            node.leftChild = buildTree();   // build & attach left subtree completely
        }

        System.out.println("Does node " + data + " have a RIGHT child? (y/n)");
        String right = scanner.next();
        if (right.equalsIgnoreCase("y")) {
            node.rightChild = buildTree();  // build & attach right subtree completely
        }

        return node;
    }

    public static void main(String[] args) {

        BinaryTree bt = new BinaryTree();

        System.out.println("Let's build your binary tree.");
        BTNode root = buildTree();
        bt.setRoot(root);

        System.out.println("\n--- Inorder Traversal ---");
        bt.printUsingInorder();

        System.out.println("\n--- Preorder Traversal ---");
        bt.printUsingPreOrder();

        System.out.println("\n--- Postorder Traversal ---");
        bt.printUsingPostOrder();

        System.out.println("\nTotal Nodes: " + bt.countNodes());
        System.out.println("Total Leaf Nodes: " + bt.countLeafNodes());

        System.out.println("\nEnter a value to count its occurrences in the tree:");
        int value = scanner.nextInt();
        System.out.println("Count of nodes with value " + value + ": " + bt.countNodesWithValue(value));

        scanner.close();
    }
}