package org.rugom.binarytree;

public class BinaryTree {

    private BTNode root;

    public BinaryTree() {
        root = null;
    }

    public void setRoot(BTNode root) {
        this.root = root;
    }

    public BTNode getRoot() {
        return root;
    }

    // ---------------- Traversals ----------------

    public void printUsingInorder() {
        printUsingInorder(root);
    }

    private void printUsingInorder(BTNode node) {
        if (node == null) return;

        printUsingInorder(node.leftChild);
        System.out.println(node.data);
        printUsingInorder(node.rightChild);
    }

    // Assignment name: printUsingPreorder()
    public void printUsingPreorder() {
        printUsingPreorder(root);
    }

    private void printUsingPreorder(BTNode node) {
        if (node == null) return;

        System.out.println(node.data);
        printUsingPreorder(node.leftChild);
        printUsingPreorder(node.rightChild);
    }

    // Assignment name: printUsingPostorder()
    public void printUsingPostorder() {
        printUsingPostorder(root);
    }

    private void printUsingPostorder(BTNode node) {
        if (node == null) return;

        printUsingPostorder(node.leftChild);
        printUsingPostorder(node.rightChild);
        System.out.println(node.data);
    }

    // Keep your existing method names too (so Main compiles)
    public void printUsingPreOrder() { printUsingPreorder(); }
    public void printUsingPostOrder() { printUsingPostorder(); }

    // ---------------- Counting ----------------

    // Assignment name: CountNodes()
    public int CountNodes() {
        return CountNodes(root);
    }

    private int CountNodes(BTNode node) {
        if (node == null) return 0;
        return 1 + CountNodes(node.leftChild) + CountNodes(node.rightChild);
    }

    // Keep your existing method name too
    public int countNodes() { return CountNodes(); }

    // Assignment name: CountLeafNodes()
    public int CountLeafNodes() {
        return CountLeafNodes(root);
    }

    private int CountLeafNodes(BTNode node) {
        if (node == null) return 0;

        if (node.leftChild == null && node.rightChild == null) {
            return 1;
        }
        return CountLeafNodes(node.leftChild) + CountLeafNodes(node.rightChild);
    }

    // Keep your existing method name too
    public int countLeafNodes() { return CountLeafNodes(); }

    // Assignment name: CountNodesWithValue(int value)
    public int CountNodesWithValue(int value) {
        return CountNodesWithValue(root, value);
    }

    private int CountNodesWithValue(BTNode node, int value) {
        if (node == null) return 0;

        int match = (node.data == value) ? 1 : 0;
        return match
                + CountNodesWithValue(node.leftChild, value)
                + CountNodesWithValue(node.rightChild, value);
    }

    // Keep your existing method name too
    public int countNodesWithValue(int value) { return CountNodesWithValue(value); }
}