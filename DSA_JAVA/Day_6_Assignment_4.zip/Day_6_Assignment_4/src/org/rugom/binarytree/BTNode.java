package org.rugom.binarytree;

public class BTNode {
	int data;
	BTNode leftChild=null;
	BTNode rightChild=null;
	
	public BTNode(int element) {
		this.data=element;
		leftChild=null;
		rightChild=null;
		
	}
	
	
	
}
