package day4;

public class Program {
    
	public static void main(String[] args) {
		
	

		Date objDate = new Date();
		int choice;
		
		do {
			System.out.println("1.Set Date\n2.Add  Date\n3.Add month\n4.Add Year\n5.Display\n6.Exit");
			choice=ConsoleInput.getInt();
			
		
			
			switch(choice){
			
			case 1:{
				
				System.out.println("Enter Day");
				int day=ConsoleInput.getInt();
				System.out.println("Enter month");
				int month=ConsoleInput.getInt();
				System.out.println("Enter year");
				int year=ConsoleInput.getInt();
				
				objDate.setDate(day,month,year);
				System.out.println("---------------------------");
				break;
			}
			case 2:{
				System.out.println("Enter day to add");
				
				int day=ConsoleInput.getInt();
				
				objDate.addDate(day);
				
				
				break;
			}
			case 3:{
				System.out.println("Enter month to add");
				int month=ConsoleInput.getInt();
				objDate.addMonth(month);
				break;
			}
			case 4:{
				break;
			}
			case 5:{
				System.out.println(objDate.getDay()+"/"+objDate.getMonth()+"/"+objDate.getYear());
				break;
			}
			case 6:{
				break;
			}
			
			
			default:
				System.out.println("Invalid Input");
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			}
			
			
		}while(choice!=6);
		
	}

}


