package day4;

public class Date {
		private int day;
		
		private int month;
		
		private int year;
		
		
		public Date() {
	        setDate(1, 1, 1950);
	    } 
		
		
		public Date(int day,int month,int year) {
			setDate(day,month,year);
			
			
		}
		
		public void setDate (int day,int month,int year) {
			
		
			if(year<1950 || year> 2050) {
				this.year=1;
			}
			else {
				this.year=year;
			}
			
			if(month<1 || month>12) {
				this.month=1;
			}
			else {
				this.month=month;
			}
			
			
			if( month==1 || month==3 || month==5 || month==7 || month == 8 || month==10 || month==12) {
			
				if(day<1||day>31) {
				this.day=1;
				
			}
			else {
				this.day=day;
				}
			}
			
			
			else if(month == 4 || month == 6 || month==9 || month==11 ){
				
				if(day<1||day>30) {
					this.day=1;
					
				}
				else {
					this.day=day;
				}
			}
			
			
			else if (month==2){
				if(day<1 || day>28)
					this.day=1;
				else
					this.day=day;
				
			}
			
			else {
				this.day=day;
			}
			
				
		}


		
		public void addDays(int days) {
			this.day+=days;
			while(true) {
				int max_days=31;
						if(month==4||month==6||month==9||month==11) {
							max_days=30;
						}
						else if(month==2){
							max_days=28;
						}
						if(this.day<=max_days) {
							break;
						}
						this.day-=max_days;
						this.month++;
						if(this.month >12) {
							this.month=1;
							this.year++;
							
							
						}
						
					}
	
			setDate(this.day,this.month,this.year);
			
			
			
			
			
		}
		public void addDate(int days) {
			
			
			addDays(days);
			
		}
		public void addMonth(int month) {
			this.month+=month;

			if(this.month>12) {
				this.month=this.month-12;
				this.year++;
			}

			setDate(this.day, this.month, this.year);
		}
		public int getDay() {
			return day;
		}

		public void setDay(int day) {
				setDate(day,this.month,this.year);
		}

		public int getMonth() {
			return month;
		}

		public void setMonth(int month) {
			setDate(this.day,month,this.year);
		}

		public int getYear() {
			return year;
		}

		public void setYear(int year) {
			setDate(this.day,this.month,year);
		}
		
		
		
}
