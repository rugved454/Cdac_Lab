let greetingModule = require("./greeting.js");

greetingModule.greet();