// 2.Create a async function which takes an array and return sum of all elements of array


async function sum(arr) {
    let sum = 0;
    arr.forEach(element => {
        sum += element
    });
    return sum;
}

let arr = [1,2,3,4,5,6,7,8,9,10];
let result = await sum(arr);
console.log(result)