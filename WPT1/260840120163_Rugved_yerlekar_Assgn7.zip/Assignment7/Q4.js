// 3.Create a async function which square each elements of the array and return the array

async function squareEachElement(arr) {
    return arr.map(element => element*element);
}

let arr = [1,2,3,4,5,6,7,8,9,10];
// let result = await squareEachElement(arr);

squareEachElement(arr)
.then(result => console.log(`Result: ${result} `)) 
.catch(e => console.log(`Error: ${e.message}`))
    