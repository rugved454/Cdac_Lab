

// 4.Write a code to read list of numbers from file and perform addition and write into another file
// (Create two file ,First file have comma seperated numbers )





const fs = require('fs');

const content  = fs.readFileSync('./file1.txt').toString();

let ans = 0;

content.split(',').forEach(e => {
    ans = ans + parseInt(e);
})

fs.writeFileSync('file2.txt', ans.toString());