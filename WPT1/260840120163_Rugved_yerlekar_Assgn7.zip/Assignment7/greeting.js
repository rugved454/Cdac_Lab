function greet() {
    let hours = new Date().getHours();
    let time = "Day"

    if(hours > 5 && hours < 12) {
        time = "Morning"
    }else if(hours >= 12 && hours < 17) {
        time = "Afternoon"
    }else {
        time = "Evening"
    }
    
     console.log(`Good ${time}`);
}
module.exports = {
    greet : greet 
}