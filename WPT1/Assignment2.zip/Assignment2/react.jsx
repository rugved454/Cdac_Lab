const Component = () => {
    return <>Hello</>
}