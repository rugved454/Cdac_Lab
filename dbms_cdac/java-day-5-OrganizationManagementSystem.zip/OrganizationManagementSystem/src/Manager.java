
public class Manager extends Employee {
	
	private float hra;

	public Manager(String name, String address, int age, boolean gender, float basicSalary) {
		super(name, address, age, gender, basicSalary);
		hra = 0.0f;
		
	}

	public float getHra() {
		return hra;
	}

	public void setHra(float hra) {
		this.hra = hra;
	}
	@Override
	void displayEmployee() {
		System.out.println("----------------------");
		System.out.println("Manager");
		super.displayEmployee();
		System.out.println("Hra: "+ hra);
		System.out.println("Total Salary: "+ (hra + basicSalary));
		System.out.println("----------------------");
	}

}
