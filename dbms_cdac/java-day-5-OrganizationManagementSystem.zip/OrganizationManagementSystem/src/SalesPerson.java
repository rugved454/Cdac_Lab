
public class SalesPerson extends Employee {
	
	private float commission;

	public SalesPerson(String name, String address, int age, boolean gender, float basicSalary) {
		super(name, address, age, gender, basicSalary);
		commission = 0.0f;
		
	}

	public float getCommission() {
		return commission;
	}

	public void setCommission(float commission) {
		this.commission = commission;
	}
	
	@Override
	void displayEmployee() {
		System.out.println("----------------------");
		System.out.println("SalesPerson");
		super.displayEmployee();
		System.out.println("Comission Rs : "+ commission);
		System.out.println("Total Salary: "+ (commission + basicSalary));
		System.out.println("----------------------");
	}
	

}
