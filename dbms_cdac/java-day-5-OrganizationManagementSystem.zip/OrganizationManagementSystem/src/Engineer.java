
public class Engineer extends Employee {
	private float overtime;
	public Engineer(String name, String address, int age, boolean gender, float basicSalary) {
		super(name, address, age, gender, basicSalary);
		overtime = 0.0f;
		
	}
	public float getOvertime() {
		return overtime;
	}
	public void setOvertime(float overtime) {
		this.overtime = overtime;
	}
	
	@Override
	void displayEmployee() {
		System.out.println("----------------------");
		System.out.println("Engineer");
		super.displayEmployee();
		System.out.println("Overtime Rs : "+ overtime);
		System.out.println("Total Salary: "+ (overtime + basicSalary));
		System.out.println("----------------------");
	}
	
}
