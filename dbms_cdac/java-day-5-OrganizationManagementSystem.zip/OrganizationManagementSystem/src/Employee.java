
public class Employee {
	
	protected String name;
	protected String address;
	protected int age;
	protected boolean gender;
	protected float basicSalary;
	
	public Employee(String name, String address, int age, boolean gender, float basicSalary) {
//		super();
		this.name = name;
		this.address = address;
		this.age = age;
		this.gender = gender;
		this.basicSalary = basicSalary;
	}

	String getName() {
		return name;
	}

	void setName(String name) {
		if(name.length() > 3 && name.length() < 20)
			this.name = name;
		else this.name = "employee";
	}

	String getAddress() {
		return address;
	}

	void setAddress(String address) {
		this.address = address;
	}

	int getAge() {
		return age;
	}

	void setAge(int age) {
		if(age > 18 && age < 70)
			this.age = age;
		else this.age = 18;
	}

	boolean isGender() {
		return gender;
	}

	void setGender(boolean gender) {
		this.gender = gender;
	}

	float getBasicSalary() {
		return basicSalary;
	}

	void setBasicSalary(float basicSalary) {
		this.basicSalary = basicSalary;
	}
	
	//getters and setters
	
	
	//methods
	
	void displayEmployee() {
		System.out.println(
				"Name: " +  getName() + "\n" +
				"Address: " +  getAddress() + "\n" +
				"Age: " +  getAge() + "\n" +
				"Gender: " +  ((isGender() == true) ? "Male" : "Female") + "\n" +
				"Basic Salary: " +  getBasicSalary()
				);
	}
	
	
	
	

}
